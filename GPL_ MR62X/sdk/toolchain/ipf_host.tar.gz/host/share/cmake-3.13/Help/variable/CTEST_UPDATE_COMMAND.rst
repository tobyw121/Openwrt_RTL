CTEST_UPDATE_COMMAND
--------------------

Specify the CTest ``UpdateCommand`` setting
in a :manual:`ctest(1)` dashboard client script.

CMAKE_OPTIMIZE_DEPENDENCIES
---------------------------

.. versionadded:: 3.19

Initializes the :prop_tgt:`OPTIMIZE_DEPENDENCIES` target property.

CTEST_CURL_OPTIONS
------------------

.. versionadded:: 3.1

Specify the CTest ``CurlOptions`` setting
in a :manual:`ctest(1)` dashboard client script.

CTEST_TEST_TIMEOUT
------------------

.. versionadded:: 3.1

Specify the CTest ``TimeOut`` setting
in a :manual:`ctest(1)` dashboard client script.

MSYS
----

.. versionadded:: 3.14

``True`` when using the :generator:`MSYS Makefiles` generator.

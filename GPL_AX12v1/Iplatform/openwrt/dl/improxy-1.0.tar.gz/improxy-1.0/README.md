improxy
=======

Improxy is an IGMP/MLD Proxy daemon written in c for Linux.
It is lightweight and do not depend on any thirdparty library. 

It support source filtering completely. 

The improxy meets the requirements of the IGMP/MLD proxy standard 
(RFC 4605) IGMPv3(rfc 3376) MLDv2(rfc 3810) and has additional functionalities.  
It support one upstream and multiple downstream.



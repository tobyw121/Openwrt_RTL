Welcome to AllJoyn
==========================================

The documentation for the project as a whole can be found in the
`alljoyn_core/docs` directory.  Most notably:

**Build instructions** are found in: `alljoyn_core/docs/BUILD.txt` (there is
also and HTML version available in the directory.

**Release Notes** are found in: `alljoyn_core/docs/ReleaseNotes.txt`
